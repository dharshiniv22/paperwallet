//
//  ForgotPasswordView.swift
//  PaperWallet
//
//  Created by SAIL on 04/12/24.
//

import UIKit

class ForgotPasswordView: UIViewController {
    
    
    
    @IBOutlet weak var emailfield: UITextField!
    
    
    
    @IBOutlet weak var passwordfield: UITextField!
    
    
    @IBOutlet weak var newpasswordfield: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    func getForgotpasswordApi() {
      
        let formData = [
            "Email": emailfield.text ?? "",
            "Password": passwordfield.text ?? "",
            "ConfirmPassword": newpasswordfield.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: ForgotPassword.self, apiUrl: APIList.forgotpassword, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                        let alert = UIAlertController(title: "Alert",
                                                      message: data.message,
                                                              preferredStyle: .alert)

                                // Create the OK action
                                let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                    // Handle the OK button tap here (if needed)
                                    self.navigationController?.popViewController(animated: false)
                                })

                                // Add the action to the alert
                                alert.addAction(okAction)

                                // Present the alert
                                self.present(alert, animated: true, completion: nil)
                            
                       
                        
                       
                    }else {
                        self.showActionSheet(Alert: "Alert", Message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                }
            }
        }
    }
    
    @IBAction func backbuttontap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func savebutton(_ sender: Any) {
        
        
        if  emailfield.text != "" && passwordfield.text == newpasswordfield.text {
            getForgotpasswordApi()
            
        }else {
            showActionSheet(Alert: "Alert", Message: "Passwords do not match. Please try again")
        }
    }
   
    
    
}
