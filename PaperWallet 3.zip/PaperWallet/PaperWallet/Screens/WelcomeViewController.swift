//
//  WelcomeViewController.swift
//  PaperWallet
//
//  Created by SAIL on 10/12/24.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
   
       
       var subHeader = ["Predict the trends, prioritize the topics, and prepare smarter.",
                        "Study smarter, not harder.",
                        "Hurray! Preparing for the exam became easy."]
       var currentItem = 0
    var image = [UIImage(named: "welcome1"),UIImage(named: "welcome3"),UIImage(named: "welcome2")]
        

    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self

       let cell = UINib(nibName: "WelcomeCell", bundle: nil)
        collectionView.register(cell, forCellWithReuseIdentifier: "WelcomeCell")
        
        
        let direction = UICollectionViewFlowLayout()
        direction.scrollDirection = .horizontal
        self.collectionView.collectionViewLayout = direction
               
    }
    
    
    
    @IBAction func nextTap(_ sender: Any) {
        
        if currentItem < 2 {
                    currentItem += 1
                  //  pageControl.currentPage = currentItem
                    let nextItem: IndexPath = IndexPath(item: currentItem, section: 0)
                    self.collectionView.scrollToItem(at: nextItem, at: .left, animated: true)
                }else {
                    currentItem = 0
                    
                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                    self.navigationController?.pushViewController(vc, animated: true)
                        }
                    
                }
    
    
    
}
extension WelcomeViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return subHeader.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WelcomeCell", for: indexPath) as! WelcomeCell
        cell.titleLbl.text = subHeader[indexPath.row]
        cell.imageView.image = image[indexPath.item]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width, height:collectionView.bounds.height)
    }
    
    
}
