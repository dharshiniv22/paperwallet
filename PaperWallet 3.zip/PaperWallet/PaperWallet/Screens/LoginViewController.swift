//
//  LoginViewController.swift
//  PaperWallet
//
//  Created by SAIL on 03/12/24.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    
    @IBOutlet weak var subView: UIView!
    
    
    @IBOutlet weak var emaIField: UITextField!
    
    
    @IBOutlet weak var passwordField: UITextField!
    
    
    
    @IBOutlet weak var loginBtn: UIButton!
    
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        subView.layer.borderWidth = 2.0
       
       
        // Do any additional setup after loading the view.
    }
    
    
    
    func getLoginApi() {
      
        let formData = [
            "Email": emaIField.text ?? "",
            "Password": passwordField.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: Login.self, apiUrl: APIList.login, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                        Manager.shared.email = self.emaIField.text ?? ""
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(withIdentifier: "UserTabbar") as! UserTabbar
                        self.navigationController?.pushViewController(vc, animated: true)
                    }else {
                        self.showActionSheet(Alert: "Alert", Message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                }
            }
        }
    }
    

    @IBAction func loginTap(_ sender: Any) {
        
        
        if emaIField.text != "" && passwordField.text != "" {
           getLoginApi()
            

        }else {
            showActionSheet(Alert: "Alert", Message: "Please fill all required fields")
        }
        
        
       
        
        
    }

    @IBAction func forgetTap(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ForgotPasswordView") as! ForgotPasswordView
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func signupTab(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SignUpView") as! SignUpView
        self.navigationController?.pushViewController(vc, animated: true)
        
        
        
        
        
        
    }
    
    
    
    
}
