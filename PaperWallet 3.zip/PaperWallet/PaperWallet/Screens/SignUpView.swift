//
//  SignUpView.swift
//  PaperWallet
//
//  Created by SAIL on 04/12/24.
//

import UIKit

class SignUpView: UIViewController {
    
    @IBOutlet weak var subview: UIView!
    
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var phonenoField: UITextField!
    
    
    @IBOutlet weak var emailField: UITextField!
    
    
    @IBOutlet weak var passwordField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
        
        func getSignUPApi() {
          
            let formData = [
                "Name": nameField.text ?? "",
                "Number": phonenoField.text ?? "",
                "Email": emailField.text ?? "",
                "Password": passwordField.text ?? ""
            ]
            
            APIHandler().postAPIValues(type: Signup.self, apiUrl: APIList.signup, method: "POST", formData: formData) { result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        if data.status == true {
                            let alert = UIAlertController(title: "Alert",
                                                          message: data.message,
                                                                  preferredStyle: .alert)

                                    // Create the OK action
                                    let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                        // Handle the OK button tap here (if needed)
                                        self.navigationController?.popViewController(animated: false)
                                    })

                                    // Add the action to the alert
                                    alert.addAction(okAction)

                                    // Present the alert
                                    self.present(alert, animated: true, completion: nil)
                                
                           
                            
                           
                        }else {
                            self.showActionSheet(Alert: "Alert", Message: data.message)
                        }
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                    }
                }
            }
        }
       
    @IBAction func backtapButton(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func signinButton(_ sender: Any) {
        if nameField.text != "" && phonenoField.text != "" && emailField.text != "" && passwordField.text != "" {
            
            getSignUPApi()
        }else {
            showActionSheet(Alert: "Alert", Message: "Please fill all required fields")
            
            
            
        }
        
        
    }
}
