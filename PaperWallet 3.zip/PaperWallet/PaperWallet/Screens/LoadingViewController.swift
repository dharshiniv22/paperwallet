//
//  LoadingViewController.swift
//  PaperWallet
//
//  Created by SAIL on 10/12/24.
//

import UIKit

class LoadingViewController: UIViewController {
    
}
