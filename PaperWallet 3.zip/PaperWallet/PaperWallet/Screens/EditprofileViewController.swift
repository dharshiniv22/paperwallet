//
//  EditprofileViewController.swift
//  PaperWallet
//
//  Created by SAIL on 13/12/24.
//

import UIKit

class EditprofileViewController: UIViewController {
    
    @IBOutlet weak var ChangeName: UITextField!
    
    
    
    @IBOutlet weak var Changephoneno: UITextField!
    
    
    
    @IBOutlet weak var Changepassword: UITextField!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    func getEditprofileApi() {
      
        let formData = [
            "Name": ChangeName.text ?? "",
            "Number": Changephoneno.text ?? "",
            "Email": "john1@gmail.com"
        ]
        
        APIHandler().postAPIValues(type: Editprofile.self, apiUrl: APIList.editprofile, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                        let alert = UIAlertController(title: "Alert",
                                                      message: data.message,
                                                              preferredStyle: .alert)
                                // Create the OK action
                                let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                    // Handle the OK button tap here (if needed)
                                    self.navigationController?.popViewController(animated: false)
                                })

                                // Add the action to the alert
                                alert.addAction(okAction)

                                // Present the alert
                                self.present(alert, animated: true, completion: nil)
                            
                       
                        
                       
                    }else {
                        self.showActionSheet(Alert: "Alert", Message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                }
            }
        }
    }

   
    @IBAction func BackTabButton(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    @IBAction func SaveButton(_ sender: Any) {
        getEditprofileApi()
    }
    
    @IBAction func LogoutButton(_ sender: Any) {
    }
    
}
