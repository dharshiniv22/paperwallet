//
//  HomeViewController.swift
//  PaperWallet
//
//  Created by SAIL on 11/12/24.
//

import UIKit
import MobileCoreServices
import PDFKit

class HomeViewController: UIViewController,UIDocumentPickerDelegate {
    
    
   
    
    
    @IBOutlet weak var viewOne: UIView!
    
    @IBOutlet weak var questionCountLbl: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    var count:Float = 0.0
    
    var selectedPDFURLs: [URL] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionCountLbl.text = "Upload Count = 0"
        progressBar.progress = count
        viewOne.layer.cornerRadius = 15
       
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        questionCountLbl.text = "Upload Count = 0"
        count = 0
        progressBar.progress = count
        
    }

    
    @IBAction func AnalyzeButton(_ sender: Any) {
        
        if count == 2 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "Resultviewcontroller") as! Resultviewcontroller
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            self.showActionSheet(Alert: "Alert", Message: "upload only pdf")
        }
      
        
//        uploadPDFsToServer(pdfURLs: selectedPDFURLs) { result in
//            DispatchQueue.main.async {
//                switch result {
//                case .success(let response):
//                    print("✅ Upload successful: \(response)")
//                case .failure(let error):
//                    print("❌ Upload failed: \(error.localizedDescription)")
//                }
//            }
//        }
    }
    
    
    
    
    
    
    @IBAction func QuestionOpenButton(_ sender: Any) {
       
        
    
    
        if count < 11.0 {
        
        let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypePDF as String], in: .import)
                documentPicker.delegate = self
                documentPicker.modalPresentationStyle = .formSheet
                present(documentPicker, animated: true, completion: nil)
        
       }else {
           showActionSheet(Alert: "Alert", Message: "")
        }
    }
    
    

    
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        selectedPDFURLs += urls // Save selected URLs

        print("Selected PDF files: \(urls)") // Debugging

        // Ensure at least 2 PDFs are selected
//        guard urls.count >= 2 else {
//            print("Please select at least 2 PDF files.")
//            return
//        }
    
        // Update progress
        count += 1.0
        progressBar.progress = count / 2.0
        questionCountLbl.text = "Upload Count = \(count)"

        // ✅ Call the upload function
        
    }
    
  
    func uploadPDFsToServer(pdfURLs: [URL], completion: @escaping (Result<[String: Any], Error>) -> Void) {
        let serverURL = URL(string: APIList.sendPDF)! // Replace with your actual PHP server URL
        let boundary = "Boundary-\(UUID().uuidString)"
        
        var request = URLRequest(url: serverURL)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()

        for (index, pdfURL) in pdfURLs.enumerated() {
            if pdfURL.startAccessingSecurityScopedResource() {
                defer { pdfURL.stopAccessingSecurityScopedResource() } // Release access
                
                guard let pdfData = try? Data(contentsOf: pdfURL) else {
                    print("❌ Could not read file: \(pdfURL.path)")
                    completion(.failure(NSError(domain: "Invalid PDF", code: 0, userInfo: [NSLocalizedDescriptionKey: "Unable to read PDF file at \(pdfURL.path)"])))
                    return
                }

                let filename = pdfURL.lastPathComponent
                let mimetype = "application/pdf"

                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"files[]\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
                body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: .utf8)!)
                body.append(pdfData)
                body.append("\r\n".data(using: .utf8)!)
            } else {
                print("❌ Could not access security-scoped resource for \(pdfURL.path)")
            }
        }

        // End of body
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "No Data", code: 0, userInfo: [NSLocalizedDescriptionKey: "Server returned no data."])))
                return
            }

            do {
                if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    completion(.success(jsonResponse))
                } else {
                    completion(.failure(NSError(domain: "Invalid Response", code: 0, userInfo: [NSLocalizedDescriptionKey: "Response is not valid JSON."])))
                }
            } catch {
                completion(.failure(error))
            }
        }

        task.resume()
    }
  


//    func uploadPDFsToServer(pdfURLs: [URL], completion: @escaping (Result<[String: Any], Error>) -> Void) {
//        let serverURL = URL(string: APIList.sendPDF)! // Change this URL to your PHP server URL
//
//        // Create the boundary string for multipart/form-data
//        let boundary = "Boundary-\(UUID().uuidString)"
//        
//        // Create the body for the multipart request
//        var body = Data()
//
//        for pdfURL in pdfURLs {
//            // Get the file data
//            guard let pdfData = try? Data(contentsOf: pdfURL) else {
//                completion(.failure(NSError(domain: "Invalid PDF", code: 0, userInfo: nil)))
//                return
//            }
//
//            // Append file data to body
//            body.append(string: "--\(boundary)\r\n")
//            body.append(string: "Content-Disposition: form-data; name=\"files[]\"; filename=\"\(pdfURL.lastPathComponent)\"\r\n")
//            body.append(string: "Content-Type: application/pdf\r\n\r\n")
//            body.append(pdfData)
//            body.append(string: "\r\n")
//        }
//        
//        body.append(string: "--\(boundary)--\r\n")
//
//        // Prepare the URLRequest
//        var request = URLRequest(url: serverURL)
//        request.httpMethod = "POST"
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("\(body.count)", forHTTPHeaderField: "Content-Length")
//        request.httpBody = body
//
//        // Start the upload task
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                completion(.failure(error))
//                return
//            }
//
//            guard let data = data else {
//                completion(.failure(NSError(domain: "No Data", code: 0, userInfo: nil)))
//                return
//            }
//
//            // Try to parse the response as JSON
//            do {
//                if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
//                    completion(.success(jsonResponse))
//                } else {
//                    completion(.failure(NSError(domain: "Invalid Response", code: 0, userInfo: nil)))
//                }
//            } catch {
//                completion(.failure(error))
//            }
//        }
//        
//        // Start the task
//        task.resume()
//    }

    

   

//
//    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
//        // Save selected URLs
//        selectedPDFURLs += urls
//
//        // Debugging: Print selected files
//        print("Selected PDF files: \(urls)")
//
//        // Update progress
//        count += 1.0
//        progressBar.progress = count / 10.0
//        questionCountLbl.text = "Upload Count = \(count)"
//
//        // Ensure at least one file is selected before uploading
//        guard !urls.isEmpty else {
//            print("No PDFs selected.")
//            return
//        }
//        
        

        // Upload selected PDFs
//        uploadPDFsToServer(pdfURLs: urls) { result in
//            DispatchQueue.main.async {
//                switch result {
//                case .success(let response):
//                    print("Upload successful: \(response)")
//                case .failure(let error):
//                    print("Upload failed: \(error.localizedDescription)")
//                }
//            }
//        }
    


    
  
        
        // Delegate method in case the user cancels the picker
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            print("Document picker was cancelled")
        }
    
//    func getForgotpasswordApi() {
//      
//        let formData = [
//            "name1": "\(selectedPDFURLs[0])",
//            "name2": "\(selectedPDFURLs[1])",
//            
//        ]
//        
//        APIHandler().postAPIValues(type: PDF.self, apiUrl: APIList.uploadPDF, method: "POST", formData: formData) { result in
//            switch result {
//            case .success(let data):
//                DispatchQueue.main.async {
//                    if data.status == true {
//                        print(data)
//                        let alert = UIAlertController(title: "Alert",
//                                                      message: data.message,
//                                                              preferredStyle: .alert)
//
//                                // Create the OK action
//                                let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
//                                    // Handle the OK button tap here (if needed)
//                                    self.navigationController?.popViewController(animated: false)
//                                })
//
//                                // Add the action to the alert
//                                alert.addAction(okAction)
//
//                                // Present the alert
//                                self.present(alert, animated: true, completion: nil)
//                            
//                       
//                        
//                       
//                    }else {
//                        self.showActionSheet(Alert: "Alert", Message: data.message)
//                    }
//                }
//            case .failure(let error):
//                print(error)
//                DispatchQueue.main.async {
//                    self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
//                }
//            }
//        }
//    }
    


    
    

    func displayPDF(from url: URL) {
        let pdfView = PDFView(frame: self.view.bounds)
        pdfView.autoScales = true
        if let document = PDFDocument(url: url) {
            pdfView.document = document
            self.view.addSubview(pdfView)
        }
    }
    
    
  
  

}





// Helper to append a string to Data
extension Data {
    mutating func append(string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}
//func uploadPDFsToServer(pdfURLs: [URL], completion: @escaping (Result<[String: Any], Error>) -> Void) {
//    // Replace with your actual server URL
//    let serverURL = URL(string: APIList.sendPDF)!
//
//    // Create the boundary string for multipart/form-data
//    let boundary = "Boundary-\(UUID().uuidString)"
//    
//    // Create the body for the multipart request
//    var body = Data()
//
//    for pdfURL in pdfURLs {
//        // Ensure the PDF file exists and can be read
//        guard let pdfData = try? Data(contentsOf: pdfURL) else {
//            completion(.failure(NSError(domain: "Invalid PDF", code: 0, userInfo: [NSLocalizedDescriptionKey: "Unable to read PDF file at \(pdfURL.path)"])))
//            return
//        }
//
//        // Append the file data to the body
//        body.append(string: "--\(boundary)\r\n")
//        body.append(string: "Content-Disposition: form-data; name=\"files[]\"; filename=\"\(pdfURL.lastPathComponent)\"\r\n")
//        body.append(string: "Content-Type: application/pdf\r\n\r\n")
//        body.append(pdfData)
//        body.append(string: "\r\n")
//    }
//    
//    // End the boundary
//    body.append(string: "--\(boundary)--\r\n")
//
//    // Prepare the URLRequest
//    var request = URLRequest(url: serverURL)
//    request.httpMethod = "POST"
//    request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//    request.setValue("\(body.count)", forHTTPHeaderField: "Content-Length")
//    request.httpBody = body
//
//    // Start the upload task
//    let task = URLSession.shared.dataTask(with: request) { data, response, error in
//        // Handle any errors that occur during the request
//        if let error = error {
//            completion(.failure(error))
//            return
//        }
//
//        // Ensure the server returned a response
//        guard let data = data else {
//            completion(.failure(NSError(domain: "No Data", code: 0, userInfo: [NSLocalizedDescriptionKey: "Server returned no data."])))
//            return
//        }
//
//        // Log the raw response for debugging purposes
//        if let responseStr = String(data: data, encoding: .utf8) {
//            print("Server Response: \(responseStr)")
//        }
//
//        // Attempt to parse the server's response as JSON
//        do {
//            if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
//                completion(.success(jsonResponse))
//            } else {
//                completion(.failure(NSError(domain: "Invalid Response", code: 0, userInfo: [NSLocalizedDescriptionKey: "Response is not valid JSON."])))
//            }
//        } catch {
//            // Log the error and return it in the completion handler
//            print("Error parsing JSON: \(error.localizedDescription)")
//            completion(.failure(error))
//        }
//    }
//    
//    // Start the task
//    task.resume()
//}
