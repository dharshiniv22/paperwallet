//
//  TopicsCoveredViewController.swift
//  PaperWallet
//
//  Created by SAIL on 14/12/24.
//

import UIKit


struct QuestionVariation: Decodable {
    let paper: String
    let question: String
}

// Define the Question model and use CodingKeys for custom mapping
struct Question: Decodable {
    let questionId: Int
    let questionVariations: [QuestionVariation]
    
    // Custom keys to match the JSON structure
    enum CodingKeys: String, CodingKey {
        case questionId = "question_id"
        case questionVariations = "question_variations"
    }
}


class QuestionMappingViewController: UIViewController {
    
    
    
    let jsonString = """
       [
           {
               "question_id": 1,
               "question_variations": [
                   {
                       "paper": "2 marks (10 questions)",
                       "question": "What is the IP protocol?"
                   },
                   {
                       "paper": "main paper",
                       "question": "What is the function of the IP protocol in the network layer?"
                   }
               ]
           },
           {
               "question_id": 2,
               "question_variations": [
                   {
                       "paper": "2 marks (10 questions)",
                       "question": "What is DNS?"
                   },
                   {
                       "paper": "main paper",
                       "question": "What is DNS, and why is it important?"
                   }
               ]
           },
           {
               "question_id": 3,
               "question_variations": [
                   {
                       "paper": "2 marks (10 questions)",
                       "question": "What is a firewall?"
                   },
                   {
                       "paper": "12 marks (5 questions)",
                       "question": "Explain the concept of network security, including cryptography, firewalls, and VPNs, and give examples."
                   }
               ]
           },
           {
               "question_id": 4,
               "question_variations": [
                   {
                       "paper": "2 marks (10 questions)",
                       "question": "What is the transport layer responsible for?"
                   },
                   {
                       "paper": "main paper",
                       "question": "What service does the Transport Layer provide to the upper layers?"
                   }
               ]
           },
           {
               "question_id": 5,
               "question_variations": [
                   {
                       "paper": "12 marks (5 questions)",
                       "question": "Describe the transport layer protocols, including UDP and TCP, and explain their differences."
                   },
                   {
                       "paper": "main paper",
                       "question": "Differentiate between UDP and TCP in terms of reliability."
                   },
                   {
                       "paper": "main paper",
                       "question": "What is the purpose of the UDP protocol in Internet communication?"
                   }
               ]
           }
       ]
       """
    
    var questions: [Question] = []
    
    var allQuestions: [String] = []
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        let cell = UINib(nibName: "QusTableViewCell", bundle: nil)
        tableView.register(cell, forCellReuseIdentifier: "QusTableViewCell")
      
        LoadingIndicator.shared.showLoading(on: self.view)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.parseJSON()
            
        }
    }
    
    func parseJSON() {
            if let data = jsonString.data(using: .utf8) {
                let decoder = JSONDecoder()
                
                do {
                    // Decode the data into an array of questions
                    let decodedQuestions = try decoder.decode([Question].self, from: data)
                    self.questions = decodedQuestions
                    
                    let val = self.questions.map{$0.questionVariations.map{$0.question}}
                    let wk = val.flatMap{$0}
                    allQuestions.append(contentsOf: wk)
                    getLoginApi()
                    LoadingIndicator.shared.hideLoading()
                  
                        self.tableView.reloadData()
                    

                    
                } catch {
                    LoadingIndicator.shared.hideLoading()
                    print("Failed to decode JSON: \(error)")
                }
            }
        }
    
    
    
    func getLoginApi() {
      
        let formData = [
            "content": allQuestions.first ?? "",
            "email": Manager.shared.email
        ]
        
        APIHandler().postAPIValues(type: ForgotPassword.self, apiUrl: APIList.recent, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                       
                    }else {
                       // self.showActionSheet(Alert: "Alert", Message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                  //  self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                }
            }
        }
    }
    
    
    @IBAction func BackTab(_ sender: Any) {
    
       
        self.navigationController?.popViewController(animated: false)
        
      
        
       
    }
    

}
extension QuestionMappingViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.allQuestions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "QusTableViewCell", for: indexPath) as! QusTableViewCell
     
        cell.questionLbl.text = "\(indexPath.row + 1)): \(allQuestions[indexPath.row])"
            
        
      
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    
}
