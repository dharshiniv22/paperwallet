//
//  Resultviewcontroller.swift
//  PaperWallet
//
//  Created by SAIL on 05/12/24.
//

import UIKit

class Resultviewcontroller: UIViewController {
    
    
    @IBOutlet weak var ViewOne: UIView!
    
 
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        
        ViewOne.layer.cornerRadius = 30
  

        // Do any additional setup after loading the view.
    }

    
    
    
    

    
    @IBAction func BackButton(_ sender: Any) {
    
    
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
    @IBAction func ViewButton(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "QuestionMappingViewController") as! QuestionMappingViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    

}
