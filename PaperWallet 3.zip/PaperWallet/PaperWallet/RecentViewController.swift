//
//  RecentViewController.swift
//  PaperWallet
//
//  Created by SAIL on 11/12/24.
//

import UIKit

class RecentViewController: UIViewController {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    var historyList = [HistoryDatum]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        let cell = UINib(nibName: "NotificationCell", bundle: nil)
        tableView.register(cell, forCellReuseIdentifier: "NotificationCell")
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        getLoginApi()
    }

    
    @IBAction func DeleteButton(_ sender: Any) {
        
        
    }
    
    
    func getLoginApi() {
      
      
        
        APIHandler().getAPIValues(type: History.self, apiUrl: APIList.history, method: "GET") { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                        self.historyList = data.data
                        self.tableView.reloadData()
                    }else {
                        self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                }
            }
        }
    }
    
}
extension RecentViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return historyList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath) as! NotificationCell
        cell.contentLbl.text = historyList[indexPath.row].content
        cell.date.text = historyList[indexPath.row].date
        cell.time.text = historyList[indexPath.row].time
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    
}
