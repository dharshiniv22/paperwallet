//
//  SettingViewController.swift
//  PaperWallet
//
//  Created by SAIL on 11/12/24.
//

import UIKit

class ProfileViewController: UIViewController {
    
    
    
    @IBOutlet weak var name: UILabel!
    
    
    @IBOutlet weak var phoneno: UILabel!
    
    @IBOutlet weak var emailid: UILabel!
    
    
    @IBOutlet weak var password: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        getMyprofileApi() 
    }
  
    func getMyprofileApi() {
      
        let formData = [
            "Email": "john1@gmail.com",
            "Password": "55"
        ]
        
        APIHandler().postAPIValues(type: Myprofile.self, apiUrl: APIList.myprofile, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                        self.name.text = data.user.name
                        self.phoneno.text = data.user.phone
                        self.emailid.text = data.user.email
        
                        
                        
                    }else {
                        self.showActionSheet(Alert: "Alert", Message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                }
            }
        }
    }
    
    
    @IBAction func Editprofilebutton(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "EditprofileViewController") as! EditprofileViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
        
    }
    
    
    @IBAction func Deleteaccount(_ sender: Any) {
        
        getDeleteaccountApi()
        
    }
        
        func getDeleteaccountApi() {
          
            let formData = [
                "email": Manager.shared.email,
               
            ]
            
            APIHandler().postAPIValues(type: Editprofile.self, apiUrl: APIList.delete, method: "POST", formData: formData) { result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        if data.status == true {
                            let alert = UIAlertController(title: "Alert",
                                                          message: data.message,
                                                                  preferredStyle: .alert)

                                    // Create the OK action
                                    let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                        if let navigationController = self.navigationController {
                                            for viewController in navigationController.viewControllers {
                                                if viewController is WelcomeViewController {
                                                    navigationController.setViewControllers([viewController], animated: true)
                                                    break
                                                }
                                            }
                                        }
                                    })

                                    // Add the action to the alert
                                    alert.addAction(okAction)

                                    // Present the alert
                                    self.present(alert, animated: true, completion: nil)
                                
                           
                            
                           
                        }else {
                            self.showActionSheet(Alert: "Alert", Message: data.message)
                        }
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.showActionSheet(Alert: "Alert", Message: "Something went wrong!")
                    }
                }
            }
        }
        
        
        
        
        
        
        
        
        
    
    
    
    
    
    
    @IBAction func Logoutbutton(_ sender: Any) {

        
        showAlert(on: self)
        
    }
    
    func showAlert(on viewController: UIViewController) {
        // Create the alert controller
        let alert = UIAlertController(title: "Alert",
                                       message: "Are you sure you want to logout?",
                                       preferredStyle: .alert)
        
        // Add "OK" action
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            if let navigationController = self.navigationController {
                for viewController in navigationController.viewControllers {
                    if viewController is WelcomeViewController {
                        navigationController.setViewControllers([viewController], animated: true)
                        break
                    }
                }
            }
        }
        
        // Add "Cancel" action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            print("Cancel action tapped")
            // Handle "Cancel" action here
        }
        
        // Add actions to the alert controller
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        // Present the alert
        viewController.present(alert, animated: true, completion: nil)
    }
    
    
}
