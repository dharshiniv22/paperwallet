//
//  Support.swift
//  PaperWallet
//
//  Created by SAIL on 16/12/24.
//

import Foundation
import UIKit


extension UIViewController {
    
    
    func showActionSheet(Alert:String ,Message:String) {
        let actionSheet = UIAlertController(title: Alert, message: Message, preferredStyle: .alert)
        
      
        
        let deleteAction = UIAlertAction(title: "OK", style: .destructive) { _ in
            print("Delete action selected")
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            print("Action sheet canceled")
        }
        
        actionSheet.addAction(deleteAction)
        actionSheet.addAction(cancelAction)
        
        // Present the action sheet
        self.present(actionSheet, animated: true, completion: nil)
    }

}
