//
//  Model.swift
//  PaperWallet
//
//  Created by SAIL on 08/01/25.
//

import UIKit


struct Login: Codable {
    let status: Bool
    let message: String
    let user: User
}

struct User: Codable {
    let name, email: String
}
struct Signup: Codable {
    let status: Bool
    let message: String

}
struct ForgotPassword: Codable {
    let status: Bool
    let message: String

}


struct Myprofile: Codable {
    let status: Bool
    let message: String
    let user: Users
}
struct Users: Codable {
    let name, email, phone: String
}

struct Editprofile: Codable {
    let status: Bool
    let message: String

}


struct PDF: Codable {
    let status: Bool
    let message: String
    let data: PDFDataClass
}

// MARK: - DataClass
struct PDFDataClass: Codable {
    let name1, name2: String
}

struct History: Codable {
    let status: Bool
    let data: [HistoryDatum]
}

// MARK: - Datum
struct HistoryDatum: Codable {
    let content, date, time, email: String
}

struct Deleteaccount: Codable {
    let status: Bool
    let message: String
}


class LoadingIndicator {

    static let shared = LoadingIndicator()

    private let activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.color = UIColor.gray
        indicator.hidesWhenStopped = true
        return indicator
    }()

    private init() {}

    func showLoading(on view: UIView) {
        DispatchQueue.main.async {
            self.activityIndicator.center = view.center
            view.addSubview(self.activityIndicator)
            self.activityIndicator.startAnimating()
        }
    }

    func hideLoading() {
        
        let mainQueue = DispatchQueue.main

        // Define a delay in seconds (e.g., 2 seconds)
        let delayInSeconds: Double = 0.3

        // Specify the deadline for the delay
        let deadline = DispatchTime.now() + delayInSeconds

        // Perform a task with a delay
        mainQueue.asyncAfter(deadline: deadline) {
            // Code to be executed after the delay
            self.activityIndicator.stopAnimating()
            self.activityIndicator.removeFromSuperview()
        }
        
        
     
          
        
    }
}
