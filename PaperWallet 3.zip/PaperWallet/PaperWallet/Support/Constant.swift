//
//  Constant.swift
//  PaperWallet
//
//  Created by SAIL on 08/01/25.


struct APIList {
    

static var baseUrl = "https://tc0qts41-80.inc1.devtunnels.ms/papersapi/"
   
// static var baseUrl = "http://180.235.121.245/papersapi/" live
    static var login = baseUrl+"login.php"
    static var signup = baseUrl+"usersignup.php"
    static var forgotpassword = baseUrl+"forgotpassword.php"
    static var myprofile = baseUrl+"myprofile.php"
    static var editprofile = baseUrl+"editprofile.php"
    static var sendPDF = baseUrl+"sendpdf.php"
    static var uploadPDF = baseUrl+"pdf.php"
    static var history = baseUrl+"recentretrive.php"
    static var recent = baseUrl+"recent.php"
    static var delete = baseUrl+"delete.php"

   
   
    
    
    
}


class Manager {
    
    static var shared = Manager()
    
    var email = String()
}
