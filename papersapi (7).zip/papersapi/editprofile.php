<?php

include_once 'db.php';  // Ensure the database connection is correct

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Check if data was received via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data (Assume data is sent via POST request)
    $email = isset($_POST['Email']) ? trim($_POST['Email']) : '';  // Email is used to identify user
    $name = isset($_POST['Name']) ? trim($_POST['Name']) : '';
    $number = isset($_POST['Number']) ? trim($_POST['Number']) : '';

    // Validate the input data
    if (empty($name) || empty($number)) {
        echo json_encode([
            'status' => false,
            'message' => 'Name and phone number are required!'
        ]);
        exit;
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'status' => false,
            'message' => 'Invalid email format!'
        ]);
        exit;
    }

    // Check if the phone number already exists in the database, excluding the current user's email
    try {
        $numberCheck = $conn->prepare("SELECT * FROM signup WHERE number = ? AND email != ?");
        $numberCheck->bind_param("ss", $number, $email);
        $numberCheck->execute();
        $numberResult = $numberCheck->get_result();
        if ($numberResult->num_rows > 0) {
            echo json_encode([
                'status' => false,
                'message' => 'Phone number is already registered to another account!'
            ]);
            $numberCheck->close();
            exit;
        }
        $numberCheck->close();
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error checking phone number: ' . $e->getMessage()
        ]);
        exit;
    }

    // Prepare SQL to update the data in the database
    try {
        // Prepare the SQL query to update user profile
        $query = "UPDATE signup SET name = ?, number = ? WHERE email = ?";
        
        $stmt = $conn->prepare($query);
        
        // Check if the statement was prepared successfully
        if ($stmt === false) {
            echo json_encode([
                'status' => false,
                'message' => 'Error preparing the statement: ' . $conn->error
            ]);
            exit;
        }

        // Bind the parameters
        $stmt->bind_param("sss", $name, $number, $email);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,
                'message' => 'Profile updated successfully!'
            ]);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Error executing query: ' . $stmt->error
            ]);
        }

        // Close the statement
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error during profile update: ' . $e->getMessage()
        ]);
    }

    // Close the connection
    $conn->close();

} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method!'
    ]);
}
?>
