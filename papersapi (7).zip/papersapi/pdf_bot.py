import os
import json
import base64
from http.server import BaseHTTPRequestHandler, HTTPServer
from PyPDF2 import PdfReader
import google.generativeai as genai

class MyHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
    
        received_data = json.loads(post_data.decode('utf-8'))
        print("Received data from PHP:", received_data)

 
        files = received_data.get("files", [])
        if not files:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(json.dumps({"error": "No files provided."}).encode('utf-8'))
            return

        all_text = []
        for file in files:
            file_name = file['name']
            file_content = file['content']  
            decoded_content = base64.b64decode(file_content)

       
            temp_file_path = f"temp_{file_name}"
            with open(temp_file_path, 'wb') as temp_file:
                temp_file.write(decoded_content)

      
            text = self.extract_text_from_pdf(temp_file_path)
            all_text.append(text)

           
            os.remove(temp_file_path)

        if not all_text:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(json.dumps({"error": "No valid PDF files provided."}).encode('utf-8'))
            return

        combined_text = "\n".join(all_text)

        # Configure the GenAI API (Replace 'API_KEY' with your actual key)
        genai.configure(api_key="AIzaSyDlVScB-GJ_EO1PNCNxpgGrsmPSHZvznns")  

      
        generation_config = {
            "temperature": 0.7,
            "top_p": 0.9,
            "top_k": 50,
            "max_output_tokens": 2048,
            "response_mime_type": "text/plain",
        }

       
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            generation_config=generation_config,
            system_instruction=(
               "You are an AI assistant designed to analyze exam papers and extract *repeated questions only*. The input will consist of text extracted from multiple PDFs containing exam questions. Your task is to identify questions that appear exactly or with minor rephrasing across the documents. Exclude any unrelated data or non-repeated questions."  
               "Format the output as a JSON list where each element represents a repeated question. Each element should have the following structure:"  
               "{'question_id': <unique_integer_id>, 'question_variations': [{'paper': <paper_name>, 'question': <question_text>, 'marks': <marks_awarded>}], 'occurrences': <number_of_times_question_repeats>}"  
               "** Ensure that every repeated question includes the paper name, question text, and assigned marks. **"  
               "** Count the number of times each question appears across different papers and include it in the output. **"  
               "** Provide the total number of repeated questions in the output. **"  
               "** The output should strictly match the JSON format above. **"  

            ),
        )
        chat_session = model.start_chat(history=[])

      
        response = chat_session.send_message(combined_text)
        print("Generated Response:", response.text)

      
        response_data = {
            "reply": "Processed PDF files and found repeated questions.",
            "output": response.text,
        }
        response_json = json.dumps(response_data)
        
       
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(response_json.encode('utf-8'))

    def extract_text_from_pdf(self, file_path):
        """Extracts text from a PDF file."""
        text = ""
        try:
            reader = PdfReader(file_path)
            for page in reader.pages:
                text += page.extract_text() or ""
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
        return text


server_address = ('', 8000) 
httpd = HTTPServer(server_address, MyHandler)
print("Python server is running...")
httpd.serve_forever()
