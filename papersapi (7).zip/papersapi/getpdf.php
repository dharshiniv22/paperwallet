<?php

include_once 'db.php';  // Include the database connection file

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Fetch data from the stringpdf table
try {
    $sql = "SELECT * FROM stringpdf";
    $result = $conn->query($sql);

    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'name1' => $row['name1'],
                'name2' => $row['name2']
            ];
        }
    }

    echo json_encode([
        'status' => true,
        'message' => 'Data retrieved successfully!',
        'data' => $data
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Error retrieving data: ' . $e->getMessage()
    ]);
    exit;
}

// Close the connection
$conn->close();

?>
