<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'paperwallet';
$username = 'root'; // Replace with your DB username
$password = ''; // Replace with your DB password

$conn = new mysqli($host, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    echo json_encode(["error" => "Failed to connect to the database."]);
    exit;
}

// Ensure `$_FILES['files']` is properly structured
if (!isset($_FILES['files']) || !is_array($_FILES['files']['name'])) {
    echo json_encode(["error" => "No files uploaded or invalid input structure."]);
    exit;
}

$files = $_FILES['files']; // Multiple files from form-data

// Check the number of uploaded files
$fileCount = count($files['name']);
if ($fileCount < 2) {
    echo json_encode([
        "status" => 500,
        "message" => "Please upload a minimum of 2 PDF files."
    ]);
    exit;
}
if ($fileCount > 10) {
    echo json_encode([
        "status" => 404,
        "message" => "You cannot upload more than 10 PDF files."
    ]);
    exit;
}

// Create the uploads directory if it doesn't exist
$uploadDir = 'uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$fileNames = []; // To store uploaded file names
$fileData = [];
for ($i = 0; $i < $fileCount; $i++) {
    // Ensure only PDF files are processed
    if (mime_content_type($files['tmp_name'][$i]) !== 'application/pdf') {
        echo json_encode([
            "error" => "Only PDF files are allowed.",
            "alert" => "One or more files are not in PDF format. Please upload only PDF files."
        ]);
        exit;
    }

    // Generate unique file name and move the uploaded file to the uploads directory
    $fileName = uniqid() . '_' . basename($files['name'][$i]);
    $filePath = $uploadDir . $fileName;

    if (move_uploaded_file($files['tmp_name'][$i], $filePath)) {
        $fileNames[] = $fileName; // Save the file name
        $fileData[] = [
            'name' => $fileName,
            'content' => base64_encode(file_get_contents($filePath))
        ];
    } else {
        echo json_encode([
            "error" => "Failed to save uploaded file: " . $files['name'][$i]
        ]);
        exit;
    }
}

// Prepare the JSON data to send to the Python server
$data = [
    "files" => $fileData,
];
$jsonData = json_encode($data);

// Set up the cURL request to the Python server
$url = 'http://localhost:8000'; // Python server URL
$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($jsonData)
]);

// Execute the request and capture the response
$response = curl_exec($ch);
curl_close($ch);

if ($response === false) {
    echo json_encode([
        "error" => "Failed to connect to the Python server.",
        "alert" => "There was an issue connecting to the backend. Please try again later."
    ]);
    exit;
}

// Decode the response from Python
$responseData = json_decode($response, true);

// if (!isset($responseData['data']) || !isset($responseData['data']['output'])) {
//     echo json_encode([$responseData['output']]);
//     echo json_encode([
//         "error" => "No valid AI response received from the backend."
//     ]);
//     exit;
// }

// Extract AI response
$aiResponse = $responseData['output'];

// Combine file names into a single string
$combinedFileNames = implode(',', $fileNames);

// Save file names and AI response to the database
$userId = 1; // Replace with dynamic user ID if applicable
$stmt = $conn->prepare("INSERT INTO questionpaper (user_id, pdf, ai_response) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $userId, $combinedFileNames, $aiResponse);

if (!$stmt->execute()) {
    echo json_encode([
        "error" => "Failed to save data to the database.",
        "db_error" => $stmt->error
    ]);
    exit;
}

$stmt->close();
$conn->close();

// Return success response
echo json_encode([
    "status" => 200,
    "message" => "Files uploaded and processed successfully.",
    "data" => $responseData
]);
?>
