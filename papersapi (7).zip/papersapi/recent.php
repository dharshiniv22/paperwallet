<?php

include_once 'db.php'; // Include the database connection file

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Get the form data from the POST request
$content = isset($_POST['content']) ? trim($_POST['content']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';

// Get current date and time from the system
$date = date('Y-m-d'); // Current date
$time = date('H:i:s'); // Current time

// Validate the input fields
if (empty($content)) {
    echo json_encode([
        'status' => false,
        'message' => 'Content is required!'
    ]);
    exit;
}

if (empty($email)) {
    echo json_encode([
        'status' => false,
        'message' => 'Email is required!'
    ]);
    exit;
}

try {
    // Insert the data into the history table
    $stmt = $conn->prepare("INSERT INTO history (content, date, time, email) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $content, $date, $time, $email);

    if ($stmt->execute()) {
        echo json_encode([
            'status' => true,
            'message' => 'Data saved successfully!'
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Failed to save data!'
        ]);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}

// Close the database connection
$conn->close();

?>
