<?php

include_once 'db.php';  // Include the database connection file

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Check if data was received via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data
    $email = isset($_POST['Email']) ? trim($_POST['Email']) : '';
    $password = isset($_POST['Password']) ? trim($_POST['Password']) : '';
    $confirm_password = isset($_POST['ConfirmPassword']) ? trim($_POST['ConfirmPassword']) : '';

    // Validate the input data
    if (empty($email) || empty($password) || empty($confirm_password)) {
        echo json_encode([
            'status' => false,
            'message' => 'Email, password, and confirm password are required!'
        ]);
        exit;
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'status' => false,
            'message' => 'Invalid email format!'
        ]);
        exit;
    }

    // Check if password and confirm password match
    if ($password !== $confirm_password) {
        echo json_encode([
            'status' => false,
            'message' => 'Password and confirm password do not match!'
        ]);
        exit;
    }

    // Hash the new password (using bcrypt)
    try {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error hashing password: ' . $e->getMessage()
        ]);
        exit;
    }

    // Update the password in the database
    try {
        $stmt = $conn->prepare("UPDATE signup SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashedPassword, $email);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,
                'message' => 'Password updated successfully!'
            ]);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Error updating password: ' . $stmt->error
            ]);
        }

        $stmt->close();
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error during password update: ' . $e->getMessage()
        ]);
    }

    // Close the connection
    $conn->close();

} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method!'
    ]);
}
?>
