<?php

include_once 'db.php';  // Include the database connection file

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Get the email of the logged-in user (assuming it's passed in the request)
$email = isset($_POST['Email']) ? trim($_POST['Email']) : '';  // or from session

// Validate the input data
if (empty($email)) {
    echo json_encode([
        'status' => false,
        'message' => 'Email is required!'
    ]);
    exit;
}

// Check if the email exists in the database
try {
    $stmt = $conn->prepare("SELECT * FROM signup WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // If email exists, return the user's profile details
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Return profile data (name, email, phone number)
        echo json_encode([
            'status' => true,
            'message' => 'Profile fetched successfully!',
            'user' => [
                'name' => $user['name'],
                'email' => $user['email'],
                'phone' => $user['number']  // Fetching the phone number
            ]
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Email not found!'
        ]);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Error fetching profile: ' . $e->getMessage()
    ]);
    exit;
}

// Close the connection
$conn->close();
?>
