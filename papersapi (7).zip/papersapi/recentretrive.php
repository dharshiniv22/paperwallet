<?php

include_once 'db.php'; // Include the database connection file

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Retrieve all history data ordered by most recent entries first
$sql = "SELECT content, date, time, email FROM history ORDER BY date DESC, time DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $history = [];
    while ($row = $result->fetch_assoc()) {
        $history[] = $row;
    }
    echo json_encode([
        'status' => true,
        'data' => $history
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'No history found!'
    ]);
}

// Close the database connection
$conn->close();

?>
