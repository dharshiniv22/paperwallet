<?php

include_once 'db.php';  // Include the database connection file

// Check the connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => false,
        'message' => 'Connection failed: ' . $conn->connect_error
    ]);
    exit;
}

// Check if data was received via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the form data
    $name1 = isset($_POST['name1']) ? trim($_POST['name1']) : '';
    $name2 = isset($_POST['name2']) ? trim($_POST['name2']) : '';

    // Validate the input data
    if (empty($name1) || empty($name2)) {
        echo json_encode([
            'status' => false,
            'message' => 'Both name1 and name2 are required!'
        ]);
        exit;
    }

    // Insert data into the database
    try {
        $stmt = $conn->prepare("INSERT INTO stringpdf (name1, name2) VALUES (?, ?)");
        $stmt->bind_param("ss", $name1, $name2);
        
        if ($stmt->execute()) {
            echo json_encode([
                'status' => true,
                'message' => 'Data successfully stored!',
                'data' => [
                    'name1' => $name1,
                    'name2' => $name2
                ]
            ]);
        } else {
            echo json_encode([
                'status' => false,
                'message' => 'Failed to store data!'
            ]);
        }
        
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode([
            'status' => false,
            'message' => 'Error during data storage: ' . $e->getMessage()
        ]);
        exit;
    }

    // Close the connection
    $conn->close();
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method!'
    ]);
}
?>
