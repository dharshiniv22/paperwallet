<?php
session_start();
include_once 'db.php';  // Ensure database connection is correct

// Get the user email from the POST request
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid email!'
    ]);
    exit;
}

try {
    // Prepare the delete statement
    $stmt = $conn->prepare("DELETE FROM signup WHERE email = ?");
    if ($stmt === false) {
        echo json_encode([
            'status' => false,
            'message' => 'Error preparing statement: ' . $conn->error
        ]);
        exit;
    }

    // Bind the parameter as a string
    $stmt->bind_param("s", $email);

    // Execute the query
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo json_encode([
            'status' => true,
            'message' => 'Account deleted successfully!'
        ]);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'No account found for the given email!'
        ]);
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Error during deletion: ' . $e->getMessage()
    ]);
}

// Close the connection
$conn->close();
?>
